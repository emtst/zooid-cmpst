#!/bin/bash

while true
do
  echo $RANDOM
done
