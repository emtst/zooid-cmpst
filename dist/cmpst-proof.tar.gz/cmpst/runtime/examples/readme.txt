This folder contains the code extracted from Coq after building the source
