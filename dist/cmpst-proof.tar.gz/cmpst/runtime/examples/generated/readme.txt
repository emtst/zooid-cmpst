The certified code extracted goes here.
